//
//  main.swift
//  [007]Poly
//
//  Created by CAIZHILI on 15/11/8.
//  Copyright © 2015年 CAIZHILI. All rights reserved.
//

import Foundation


let triangle = Triangle(a: 2, b: 2, c: 2)
let square = Square(sideLength: 2)
let rect = Rectangle(length: 2, width: 4)

print(triangle.getTotalSideLengh())
print(square.getTotalSideLengh())
print(rect.getTotalSideLengh())

