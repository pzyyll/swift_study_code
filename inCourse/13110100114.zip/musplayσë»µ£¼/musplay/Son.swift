//
//  Son.swift
//  musplay
//
//  Created by pzyyll on 15/12/11.
//  Copyright © 2015年 pzyyll. All rights reserved.
//

import Foundation
import UIKit

class Son {
    var img: UIImage?
    var title: String?
    var artist: String?
}